[![Github](https://img.shields.io/badge/Github-BOTOL--MEHEDI-green?style=flat-square&logo=github)](https://github.com/botolmehedi)
[![IYoutube](https://img.shields.io/badge/YOUTUBE-%40mastertrick1-red?style=flat-square&logo=youtube)](https://www.youtube.com/mastertrick1)
[![Messenger](https://img.shields.io/badge/Chat-Messenger-blue?style=flat-square&logo=messenger)](https://www.facebook.com/groups/231747098048450)

<h1 align="center">B8 v1.0</h1>
<p align="center">
      A new facebook account 8digit passwords cracker tool for termux users.
</p>

## 馃攳 ***About B8***:

B8 is a python based script. You can use this tool for crack facebook users passwords. This tool works on both rooted Android device and Non-rooted Android device.

## All commands for install this tool
$ pkg update && pkg upgrade && pkg install python && pkg install python2 && pkg install git && pkg install pip && pkg install pip2
<br/>
$ git clone https://github.com/botolmehedi/b8
<br/>
$ pip2 install requests
<br/>
$ pip2 install mechanize
<br/>
$ ls
<br/>
$ cd b8
<br/>
$ python2 b8.py
<br/>
...
<br/>
• TOOL USER : (knock me on facebook)
<br/>
• TOOL PASS : (knock me on facebook)
<br/>
....
<br/>

* Note:- Don't try to edit or modify this tool.

## 馃敆 ***Check this***

### Subscribe our channel on youtube:
https://www.youtube.com/MasterTrick1

### Chekout our webite:
https://www.mastertrick.design

## 馃懃 ***Join***

### Facebook group: 
https://www.facebook.com/groups/231747098048450

### Telegram channel:
https://t.me/mastertrick2

### Facebook page:
https://www.facebook.com/TeamVVirus

### Instagram: 
https://www.instagram.com/MehtanOfficial

### My GitHub ID link:
https://www.github.com/BotolMehedi

### 馃摙 Warning

***This tool is only for educational purpose. If you use this tool for other purposes except education we will not be responsible in such cases.***
